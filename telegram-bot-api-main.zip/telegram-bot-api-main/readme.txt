git clone --recursive https://github.com/tdlib/telegram-bot-api.git

